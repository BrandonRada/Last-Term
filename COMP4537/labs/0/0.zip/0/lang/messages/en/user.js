export const messages = {
    invalidRange: "Entered value must be in range 3-7",
    winText: "Excellent memory!",
    wrongOrder: "Wrong order!"
};